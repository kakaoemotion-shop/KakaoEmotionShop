
/*  아직 작동암됨!! 연결하지 마세요!!  */


// $(function() {
//     $('.search-button').click(function(){
//         if($('.search-page').css('display') == "none") {
//             $('.search-page').show();
//         } else {
//             $('.search-page').hide();
//         }
//     });
// }); 

// const searchInput = document.querySelector(".search-bar-input");
// function addSearchInputEvent() {
//     if(window.event.keyCode == 13) {
//         location.href = `http://127.0.0.1:8000/kakaopage/search?searchValue=${searchInput.value}}`;
//     }
// }