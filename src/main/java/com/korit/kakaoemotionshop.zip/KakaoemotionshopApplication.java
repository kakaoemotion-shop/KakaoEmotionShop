package com.korit.kakaoemotionshop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KakaoemotionshopApplication {

	public static void main(String[] args) {
		SpringApplication.run(KakaoemotionshopApplication.class, args);
	}

}
