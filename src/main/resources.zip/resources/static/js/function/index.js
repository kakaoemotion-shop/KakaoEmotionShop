window.onload = () => {
    // ToggleService.getInstance().header();
    ToggleService.getInstance().loadlogin();
    ToggleButton.getInstance().logoutButton();
    ToggleButton.getInstance().toggleButton();
    ToggleService.getInstance().footer();
}